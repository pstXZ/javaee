package com.ZPW.test;


import com.ZPW.po.Customer;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import java.io.IOException;
import java.io.InputStream;
import com.ZPW.test.sqlSessionFactoryUtil02;

public class Test {
    public static void main(String[] args) throws IOException{
        Test test = new Test();

        test.addCustomerTest();

    }

    //查询功能
    public void addCustomerTest() throws IOException{
        SqlSession sqlSession = sqlSessionFactoryUtil02.getSqlSessionFactory().openSession();
        //sqlsession执行添加操作
        Customer customer = new Customer();
        customer.setUsername("周攀蔚33");
        customer.setJobs("学生");
        customer.setPhone("13881103632");
        //执行sqlsession的传入方法
        int rows = sqlSession.insert("com.ZPW.mapper.UserMapper.addCustomer",customer);
        //返回结果判断插入是否执行
        if(rows>0){
            System.out.println("插入成功");
        }
        else {
            System.out.println("插入失败");
        }
        //提交事务
        sqlSession.commit();
        sqlSession.close();
    }
}
