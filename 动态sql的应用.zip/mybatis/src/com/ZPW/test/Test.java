package com.ZPW.test;


import com.ZPW.po.Customer;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import com.ZPW.test.sqlSessionFactoryUtil02;

public class Test {
    public static void main(String[] args) throws IOException{
        Test test = new Test();
        test.addCustomerTest();
    }

    //查询功能
    public void addCustomerTest() throws IOException{
        SqlSession sqlSession = sqlSessionFactoryUtil02.getSession();
        //sqlsession执行添加操作
        Customer customer = new Customer();
        customer.setUsername("周攀蔚");
        customer.setJobs("学生");

        List<Customer> customers = sqlSession.selectList("com.ZPW.mapper.UserMapper.findCustomerByNameAndJobs",customer);
        for (Customer customer1:customers){
            System.out.println(customer1);
        }
        sqlSession.close();
    }
}
